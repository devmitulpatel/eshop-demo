<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OTP extends Model
{
    //
    protected $table = 'mobile_otp';
}
